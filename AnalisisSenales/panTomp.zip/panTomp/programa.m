% logica principal del programa 
clc
clear all 
close all
data = load('datos.mat')%Cargar los datos
data = data.data
filtro1 = filtroPasaBaja(data);% aplicar filtro pasa baja a la senal
filtro2 = filtroPasaAlta(filtro1);%aplicar filtro pasa alta
derivador1 = derivador(filtro2);%aplicar derivador
elevador1 = elevarCuadrado(derivador1);
ventana = 22;
panTomp = integralVentana(elevador1,ventana);



% graficas
graficar(data,'Datos Capturados','Muestras','mV');
graficar(filtro1,'Se�al Filtro PasaBaja','Muestras','mV');
graficar(filtro2,'Se�al Filtro PasaAlta','Muestras','mV');
graficar(derivador1,'Se�al con Derivador','Muestras','mV');
graficar(elevador1,'Se�al Elevada al Cuadrado','Muestras','mV^2');
graficar(panTomp,'Se�al con la Integral de Ventana','Muestras','Adimesional');


% plot(filtro1);
% figure
% plot(filtro2);
% figure
% plot(derivador1);
% figure
% plot(elevador1);
% figure
% plot(panTomp);