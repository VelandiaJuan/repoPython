function graficar(vector,titulo,xlabel1,ylabel1)
    figure
    plot(vector)
    title(titulo)
    xlabel(xlabel1) 
    ylabel(ylabel1) 
end